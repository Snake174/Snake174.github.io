TwoMbit is a cycle/bus accurate emulator for Sega's 8-bit game consoles
(Master System, Gamegear, SG-1000)

includes a cross-platform emulation library, so someone could build a gui without having to know the sms internals

notes:

- if you are using a mouse as input device, the cursor is hidden after activation. Press escape to show the cursor again.

- if you are using a bios keep in mind that the combination of game, bios and region matters like the real systems. So not all combinations are working.

- there are a few pal games which have glitches playing with us/jp region selected. These are no emulation bugs. It behaves the same at a real system.

- you can emulate a sms1 or sms2 unit. Like the real system, not all games run on both revisions correctly.

- combine cheats with savestates. There are cheats which seems to work like expected, but the memory location could used for someting other later on and game crashes. So deactivate cheats before such situations. Savestates saves time and frustration if you forget that or don't expect it. 

- if you want to use a window/fullscreen resolution not listed, please modify the config.ini

- most lcd monitor supports 60 Hz only. If you want to play a pal game with original scrolling, you should use a crt monitor. With a tool like powerstrip you can prepare a resolution for 50 Hz. But beware some crt models could be damaged permanently. So read manual and find out if 50 Hz is supported.


v 1.0.5
- [bugfix] fixed interrupt recognition and timings of some z80 opcodes
- [bugfix] improved pal games autodetection
- [bugfix] improved japanese games autodetection
- [bugfix] improved mapper detection [Nemesis, Transbot, Spy, jang pung 2, Power Boggle, ...]
- [bugfix] improved cram update behaviour [Rise of the Robots, Back to the future 2]
- [bugfix] for gear to gear games in single gear mode. Frame error flag is reseted always. It seems it could be only seted by a broken connection between two gears (so no usefull for emulation) [Hyper Chou Pro Yakyuu '92]
- [bugfix] fixed a bug for gg backdrop color [Power Strike II]
- [feature] added DahJee ram emulation for SG-1000 [Kings Valley, Magical Kid Wiz]
- [feature] added custom byte flipping mapper [Janggun ui adeul]

v 1.0.4
- [bugfix] sample playback for tone counter 0 (chess games sms/gg)
- [bugfix] vdp access times for SG 1000 (Monaco GP)
- [bugfix] for gear to gear games in single gear mode. These games expect the send flag successfull seted, even the data is sended into nothing (Lemmings, GP Rider)
- [bugfix] for gear to gear mode. Some games read receive data too soon. My initial assumption was that each shifted bit is saved in an accessible register directly, but its stored in a buffer until all shifting is done. (GP Rider again)
- [bugfix] increased the distance between 2 running game gears. Some games are unable to determine about gear 1 and 2. (Popeye)
- [feature] allowed Super Tetris to run. The game don't expect port 3e. Maybe the korean sms, based on the japanese one, don't have it. I would consider this as a game specific hack.
- [feature] added command line support. Now you can assign games to the emulator.
- [feature] added the option to disable sms borders. means borders are always black and reduced. To maintain aspect ratio borders can not removed completly 
- [feature] added 4% overscan for normal border display to resemble real TV viewport, means smaller borders

v 1.0.3
- [feature] added mac support
- [feature] added linux support
- [feature] added correct aspect switch
- [bugfix] scanlines in higher resolutions were displayed too thin
- [bugfix] better autodetection of pal games (the ones, which makes problems in a ntsc region).

v 1.0.2
- [feature] cheats
- [feature] savestates
- [bugfix] vscroll cache time
- [bugfix] sprite subsystem is processing during inactive display

v 1.0.1
[general]
- switched to gcc for compiler
- switched to QT 4.8 for Gui ( c# / .net is no more )
- build libsms (cross-plattform)

[emulation]
- gamegear emulation
- sg-1000 emulation
- emulating additional cart work ram (Ernie Els Golf, the castle, Othello)
- emulating bus contention
- emulating game gear bios
- emulating custom sram sizes (Shining force)
- emulating eeprom of the baseball series games
- emulating lightphaser, paddle (japanese and export), sportspad (japanese and export), 3d glasses, Terebi Oekaki
- emulating gear-2-gear at cycle level
	- parallel (Squinky Tennis in micro machines, Primal Rage, ...)
	- serial 
	- different baud rate settings
- emulating backward compatibillity of gamegear(mastergear) and sms
- emulating yamaha2413
- fex(zip, 7z, rar, gzip), bzip2, untar for compressed roms

[bugfixes]
- removed cache for irq detection, now irqs will be detected one cpu cycle before opcode edge ( simplified the overall process)
- fixed sample playback
- differentiate between sg and sms/gg vdp delay and access window behavior.

v 1.0.0
- sms emulation
- custom mappers: codemasters, korean, korean 8k
- .net WPF gui


to do:

feature doings
- replace directx to make TwoMbit platform independant

accuracy doings
- sn76489: writing to regs will not processed without delay
- vdp: accurate access windows during sprite processing
- vdp: split sprite subprocessing in timed steps (like bg processing) and not one sprite at a time
- yamaha2413: sub sample accuracy

