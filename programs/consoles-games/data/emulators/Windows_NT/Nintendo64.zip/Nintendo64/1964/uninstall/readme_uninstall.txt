To uninstall 1964, double-click the .reg file that corresponds
to your operating system. Then delete the 1964 folder.

To uninstall the RiceDaedalus video plugin, double-click the .reg file for the video plugin.
