--This is the ending node, and is a simple "slide", just one image.
slide "end.jpeg"

--This tells Pipmak what file to use to define the "hotspots" of the node-
--regions within the panorama that allow an action to take place when the 
--player clicks on it. This is an color indexed PNG(Portable Network Graphics)
--image.
hotspotmap "hotspots.png"

--The hotspots are arranged in descending order, according to their order in
--the palatte the indexed PNG uses.  

--This tells Pipmak that when the hotspot is clicked, a function is initiated called
--"onmousedown", and within this function, we call pipmak.quit, which quits the program.
--Then we END the function.
hotspot {
  onmousedown = function()
   pipmak.quit()
  end  
} 

--This tells Pipmak that when the hotspot is clicked, a function is initiated called
--"onmousedown", and within this function, we reset the game to its initial state, e.g. 
--state.trapDoorOpen=false. Next we tell pipmak to go to node 1, to effectivly restart 
--the program.
--Then we END the function.
hotspot {
  onmousedown = function()
   state.trapDoorOpen = false
   pipmak.gotonode(1)  
  end
}
