--This loads a sound for use in the node.
local squeakSound = sound "squeak.ogg"

--This tells Pipmak what images to use to form the cubic panorama node. The
--panorama is made up of six JPEG images, front, right, back, left, top, and
--bottom. These are projected onto a virtual cube, and the players eyes are 
--placed at the center.  
cubic { "n12_front.jpg", "n12_right.jpg", "n12_back.jpg", "n12_left.jpg", "n12_top.jpg", "n12_bottom.jpg" }

--This tells Pipmak what file to use to define the "hotspots" of the node-
--regions within the panorama that allow an action to take place when the 
--player clicks on it. This is an color indexed PNG(Portable Network Graphics)
--image.
hotspotmap "hotspots.png"

--The hotspots are arranged in descending order, according to their order in
--the palatte the indexed PNG uses.  

--This tells the engine that when the hotspot is clicked, the player should 
--be transported to node "11", and that when over the hopspot, the cursor should
--change to the "pipmak.hand_forward" cursor. 
hotspot { target = 11, cursor = pipmak.hand_forward }

--This tells Pipmak that when the hotspot is clicked, a function is initiated called
--"onmousedown", and within this function, we ask Pipmak whether the trapdoor is not open,
--and if it is not, then we set the state "trapDoorOpen" to TRUE, contact patch 1 and 2,
--and tell them to be visible. Then we contacts hotspot 1 and tells it to not respond when 
--clicked, e.g. enable(false). Last of all, we call function "squeakSound" and "play".
--Then we tell Pipmak that if, else, state.trapDoorOpen=true, e.g. the trapdoor IS open, then 
--we tell pipmak to preform a diffrent action-to go to node 16. Then we END the function.
hotspot {
   onmousedown = function()
      if state.trapDoorOpen == false then
         state.trapDoorOpen = true
         pipmak.getpatch(1):setvisible(true)
         pipmak.getpatch(2):setvisible(true)
         pipmak.gethotspot(1):enable(false)
         squeakSound:play()
      else
        pipmak.gotonode(16)  
      end
   end         
}
        
   
--This loads and positions two "patches", images layered over the panorama, placing them
--on specifed faces, and giving Pipmak the exact postion in pixels. And we tell Pipmak that 
--the patches are visible only if state.trapDoorOpen=true.
patch { face = 1, x = 257, y = 377, visible = state.trapDoorOpen, image = "n12_front_trapDoorOpen.jpg"}
patch { face = 6, x = 256, y = 0, visible = state.trapDoorOpen, image = "n12_bottom_trapDoorOpen.jpg"}

