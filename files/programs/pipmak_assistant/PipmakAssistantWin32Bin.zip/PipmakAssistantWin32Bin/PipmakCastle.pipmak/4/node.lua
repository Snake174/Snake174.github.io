--This tells Pipmak what images to use to form the cubic panorama node. The
--panorama is made up of six JPEG images, front, right, back, left, top, and
--bottom. These are projected onto a virtual cube, and the players eyes are 
--placed at the center.  
cubic { "n4_front.jpg", "n4_right.jpg", "n4_back.jpg", "n4_left.jpg", "n4_top.jpg", "n4_bottom.jpg" }

--This tells Pipmak what file to use to define the "hotspots" of the node-
--regions within the panorama that allow an action to take place when the 
--player clicks on it. This is an color indexed PNG(Portable Network Graphics)
--image.
hotspotmap "hotspots.png"

--The hotspots are arranged in descending order, according to their order in
--the palatte the indexed PNG uses.  

--This tells the engine that when the hotspot is clicked, the player should 
--be transported to node "5", and that when over the hopspot, the cursor should
--change to the "pipmak.hand_forward" cursor. 
hotspot { target = 5, cursor = pipmak.hand_forward }

--This tells the engine that when the hotspot is clicked, the player should 
--be transported to node "3", and that when over the hopspot, the cursor should
--change to the "pipmak.hand_forward" cursor. 
hotspot { target = 3, cursor = pipmak.hand_forward }
