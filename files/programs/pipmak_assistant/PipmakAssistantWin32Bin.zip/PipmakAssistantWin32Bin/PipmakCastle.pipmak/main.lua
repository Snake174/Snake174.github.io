--[[ ������ ]]
version (0.27) -- fdg
title "Pipmak Castle Demo"
startnode (99)
onopenproject (
	function()
		state.trapDoorOpen = false
	end
)
