slide "frame.png"

hotspotmap "hotspots.png"

hotspot { onmousedown = function() pipmak.gotonode(19, true) end, cursor = pipmak.hand_back }