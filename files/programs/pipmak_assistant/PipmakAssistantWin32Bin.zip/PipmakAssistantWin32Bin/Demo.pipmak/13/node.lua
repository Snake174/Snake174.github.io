slide "s.jpeg"

hotspotmap "hotspots.png"

hotspot { target = 12, effect = { pipmak.rotate, pipmak.right, 60 }, cursor = pipmak.hand_left }
hotspot { target = 10, effect = { pipmak.rotate, pipmak.left, 60 }, cursor = pipmak.hand_right }

hotspot {
	onmousedown = function()
		pipmak.setviewdirection(180, 0)
		pipmak.gotonode(1)
	end,
	cursor = pipmak.hand_forward
}

patch { x = 128, y = 48, visible = (state.bridgepos > .5), image = "bridge.jpeg" }