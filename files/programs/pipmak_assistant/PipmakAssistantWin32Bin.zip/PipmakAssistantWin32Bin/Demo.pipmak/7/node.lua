cubic { "37.jpeg", "38.jpeg", "39.jpeg", "40.jpeg", "41.jpeg", "42.jpeg" }

hotspotmap "hotspots.png"

hotspot { target = 6, cursor = pipmak.hand_forward }

hotspot { target = 8, cursor = pipmak.hand_forward }

patch { face = 1, x = 141, y = 219, visible = state.lamp2on, image = "lamp2.jpeg" }
patch { face = 2, x = 14, y = 150, visible = state.lamp3on, image = "lamp3.jpeg" }
patch { face = 3, x = 424, y = 179, visible = state.lamp4on, image = "lamp4.jpeg" }

patch { face = 4, x = 437, y = 240, visible = state.doorisopen, image = "door.jpeg" }

sound { "../sound/motor.ogg", az = 233, el = -14, volume = 0.1, loop = true, autoplay = true }
