cubic { "31.jpeg", "32.jpeg", "33.jpeg", "34.jpeg", "35.jpeg", "36.jpeg" }

hotspotmap "hotspots.png"

hotspot { target = 5, cursor = pipmak.hand_forward }

hotspot { target = 7, cursor = pipmak.hand_forward }

patch { face = 1, x = 143, y = 212, visible = state.lamp2on, image = "lamp2.jpeg" }
patch { face = 2, x = 153, y = 169, visible = state.lamp3on, image = "lamp3.jpeg" }
patch { face = 4, x = 268, y = 221, visible = state.lamp1on, image = "lamp1.jpeg" }

patch { face = 4, x = 384, y = 238, visible = state.doorisopen, image = "door.jpeg" }

patch { face = 4, x = 48, y = 80, visible = (state.bridgepos > .5), image = "bridge.jpeg" }
