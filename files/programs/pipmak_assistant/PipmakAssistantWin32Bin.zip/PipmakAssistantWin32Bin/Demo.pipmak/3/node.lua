cubic { "13.jpeg", "14.jpeg", "15.jpeg", "16.jpeg", "17.jpeg", "18.jpeg" }

hotspotmap "hotspots.png"

hotspot { target = 2, cursor = pipmak.hand_forward }

hotspot { target = 4, cursor = pipmak.hand_forward }

patch { face = 3, x = 184, y = 146, visible = state.lamp4on, image = "lamp4.jpeg" }
patch { face = 4, x = 377, y = 203, visible = state.lamp1on, image = "lamp1.jpeg" }

patch { face = 1, x = 327, y = 0, visible = (state.bridgepos > .5), image = "bridge-13.jpeg" }
patch { face = 2, x = 0, y = 0, visible = (state.bridgepos > .5), image = "bridge-14.jpeg" }
patch { face = 5, x = 448, y = 426, visible = (state.bridgepos > .5), image = "bridge-17.jpeg" }

local wheel = patch { face = 2, x = 180, y = 273, image = "wheel0.jpeg" }
local wheelpos = 0

sound { "../sound/motor.ogg", az = 78, el = -7, volume = 0.1, loop = true, autoplay = true }

onenternode (
	function()
		pipmak.schedule(
			0.05,
			function()
				wheelpos = math.mod(wheelpos + 1, 6)
				wheel:setimage("wheel" .. wheelpos .. ".jpeg")
				return 0.05
			end
		)
	end
)