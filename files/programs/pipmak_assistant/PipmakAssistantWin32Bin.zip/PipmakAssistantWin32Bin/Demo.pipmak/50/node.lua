-- This is a general-purpose inventory - feel free to reuse and adapt in your
-- own projects.
--
-- The inventory is a panel node and can be accessed using the global variable
-- "inventory" to which it assigns itself when entered.
-- The inventory contents are represented by the table state.inventory, a list
-- of strings. For every possible object, there is a 48x48 PNG "<object>.png"
-- in this node's folder. Add an object to the inventory by sending a "pickup"
-- message to this node with the object name as an argument. Remove an object
-- by sending a "drop" message with its list index as an argument. The default
-- behavior of an object in the inventory is that clicking on it will make it
-- follow the mouse cursor for 10 seconds. During that time,
-- state.inventory.carried will be the index of that object (i.e.
-- state.inventory[state.inventory.carried] will be its name). At other times,
-- state.inventory.carried is nil. If an object should behave differently when
-- clicked, add a function with its name as the key to the "actions" table
-- below. That function will receive one argument, the index of the clicked
-- object.

local actions = {
	note = function()
		if state.inventory.carried == nil then
			pipmak.overlaynode(51) --show the note
		end
	end
}

local width = math.max(table.getn(state.inventory)*(48 + 8) + 8, 40)

panel {
	"inventory.png",
	w = width, h = 56,
	relx = 0.5, rely = 1,
	absx = -width/2, absy = -1
}

local isshown = false
local mousemodetoken
local function show(newstate)
	if newstate ~= isshown then
		isshown = newstate
		pipmak.thisnode():moveto(0.5, 1, -width/2, isshown and -56 or -1, 0.25)
		if isshown then
			mousemodetoken = pipmak.pushmousemode(pipmak.joystick)
		else
			pipmak.popmousemode(mousemodetoken)
		end
	end
end

onenternode(function() inventory = pipmak.thisnode() end)
onleavenode(function() show(false) state.inventory.carried = nil end)

onmouseenter(function() show(true) end)
onmouseleave(function() show(false) end)
onkeydown(function(key) if key == string.byte(" ") then show(not isshown) return true end end)

handle { x = 0, y = 0, w = width, h = 56 } --without this, the node wouldn't catch mouse events because it's more than half transparent

local returntime
local returnduration = 0.5

local function followmouse(patch)
	local x, y = patch:location()
	return function(now)
		local mx, my = pipmak.mouseloc()
		mx = mx - 24
		my = my + 10
		patch:moveto(mx, my)
		if now < returntime then
			return 0
		else
			pipmak.thisnode():moveto(0.5, 1, -width/2, -56, 0.25)
			pipmak.schedule(
				0,
				function(now)
					if now > returntime + returnduration then
						patch:moveto(x, y)
						state.inventory.carried = nil
						if not isshown then pipmak.thisnode():moveto(0.5, 1, -width/2, -1, 0.25) end
					else
						local l = (now-returntime)/returnduration
						patch:moveto(l*x + (1-l)*mx, l*y + (1-l)*my)
						return 0
					end
				end
			)
		end
	end
end

for i = 1, table.getn(state.inventory) do
	local j = i --this variable is recreated in each iteration so that each handle gets its own copy of it
	local mypatch = patch {
		x = 8 + (i-1)*(48 + 8), y = 6, w = 48, h = 48,
		image = state.inventory[i]..".png"
	}
	handle {
		x = 8 + (i-1)*(48 + 8), y = 6, w = 48, h = 48,
		onmousedown = function()
			if state.inventory.carried == j then
				returntime = pipmak.now() --return immediately
			else
				local f = actions[state.inventory[j]]
				if f ~= nil then
					f(j)
				else
					if state.inventory.carried == nil then
						returntime = pipmak.now() + 10
						state.inventory.carried = j
						pipmak.schedule(0, followmouse(mypatch))
					end
				end
			end
		end
	}
end

messages {
	pickup = function(object)
		table.insert(state.inventory, object)
		pipmak.thisnode():closeoverlay()
		pipmak.overlaynode(pipmak.thisnode():getid())
		inventory:message("slideback", table.getn(state.inventory)) --call code that needs to run in the new instance of this node
	end,
	
	drop = function(index)
		index = index or state.inventory.carried
		if index then
			pipmak.thisnode():closeoverlay()
			table.remove(state.inventory, index)
			state.inventory.carried = nil
			inventory = pipmak.overlaynode(pipmak.thisnode():getid())
		end
	end,
	
	--internally used
	slideback = function(n)
		pipmak.schedule(0, function() --do this in the next frame instead of right now to accommodate for the time required to load the image of the newly added item
			returntime = pipmak.now()
			pipmak.schedule(0, followmouse(pipmak.getpatch(n)))
		end)
	end
}