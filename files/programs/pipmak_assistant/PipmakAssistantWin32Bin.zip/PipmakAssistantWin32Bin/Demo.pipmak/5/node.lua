cubic { "25.jpeg", "26.jpeg", "27.jpeg", "28.jpeg", "29.jpeg", "30.jpeg" }

hotspotmap "hotspots.png"

hotspot { target = 4, cursor = pipmak.hand_forward }

hotspot { target = 6, cursor = pipmak.hand_forward }

patch { face = 4, x = 185, y = 47, visible = (state.bridgepos > .5), image = "bridge-28.jpeg" }
patch { face = 5, x = 1, y = 182, visible = (state.bridgepos > .5), image = "bridge-29.jpeg" }

patch { face = 1, x = 198, y = 217, visible = state.lamp2on, image = "lamp2.jpeg" }
patch { face = 2, x = 134, y = 194, visible = state.lamp3on, image = "lamp3.jpeg" }
patch { face = 3, x = 303, y = 189, visible = state.lamp4on, image = "lamp4.jpeg" }
patch { face = 4, x = 300, y = 215, visible = state.lamp1on, image = "lamp1.jpeg" }

patch { face = 1, x = 1, y = 233, visible = state.doorisopen, image = "door.jpeg" }

sound { "../sound/motor.ogg", az = 150, el = -12, volume = 0.15, loop = true, autoplay = true }
