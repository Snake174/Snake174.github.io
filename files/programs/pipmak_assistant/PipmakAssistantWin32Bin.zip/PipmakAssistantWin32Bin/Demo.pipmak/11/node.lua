slide "n.jpeg"

hotspotmap "hotspots.png"

hotspot { target = 10, effect = { pipmak.rotate, pipmak.right, 60 }, cursor = pipmak.hand_left }
hotspot { target = 12, effect = { pipmak.rotate, pipmak.left, 60 }, cursor = pipmak.hand_right }

patch { x = 334, y = 123, visible = state.lamp2on, image = "lamp.jpeg" }