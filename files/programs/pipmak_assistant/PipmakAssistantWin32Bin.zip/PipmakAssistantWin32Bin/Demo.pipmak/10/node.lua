slide "w.jpeg"

local click1 = sound { "../sound/click1.ogg", volume = 0.5 }
local click2 = sound { "../sound/click2.ogg", volume = 0.5 }
local doorslide = sound "../sound/slide.ogg"

hotspotmap "hotspots.png"

hotspot { target = 13, effect = { pipmak.rotate, pipmak.right, 60 }, cursor = pipmak.hand_left }

hotspot { target = 11, effect = { pipmak.rotate, pipmak.left, 60 }, cursor = pipmak.hand_right }

hotspot { target = 15, cursor = pipmak.hand_forward, enabled = state.doorisopen }

hotspot {
	onmousedown = function()
		click1:play()
		pipmak.getpatch(1):setvisible(true)
		pipmak.schedule (
			0.4,
			function()
				click2:play()
				pipmak.getpatch(1):setvisible(false)
				pipmak.schedule(0.25, function() doorslide:play() end)
				state.doorisopen = not state.doorisopen
				pipmak.gethotspot(3):enable(state.doorisopen)
				pipmak.wipe(state.doorisopen and pipmak.right or pipmak.left, 1)
				pipmak.getpatch(2):setvisible(not state.doorisopen)
			end
		)
	end
}

patch { x = 83, y = 378, visible = false, image = "button.jpeg" }

patch { x = 144, y = 56, visible = not state.doorisopen, image = "door.png" }
