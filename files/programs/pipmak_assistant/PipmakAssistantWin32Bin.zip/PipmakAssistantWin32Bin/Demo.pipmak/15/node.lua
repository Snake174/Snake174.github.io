slide "w.jpeg"

hotspotmap "hotspots.png"

hotspot { target = 16, effect = { pipmak.rotate, pipmak.right, 90 }, cursor = pipmak.hand_lleft }
hotspot { target = 16, effect = { pipmak.rotate, pipmak.left, 90 }, cursor = pipmak.hand_rright }
hotspot { target = 18, cursor = pipmak.hand_zoom }

if backgroundsound == nil then
	backgroundsound = sound { "../sound/background.ogg", loop = true, volume = 0.5 }
end

onenternode (
	function()
		if not backgroundsound:playing() then backgroundsound:play() end
	end
)
