cubic { "19.jpeg", "20.jpeg", "21.jpeg", "22.jpeg", "23.jpeg", "24.jpeg" }

hotspotmap "hotspots.png"

hotspot { target = 3, cursor = pipmak.hand_forward }

hotspot { target = 5, cursor = pipmak.hand_forward }

onleavenode( function() state.bridgepos = math.floor(state.bridgepos + 0.5) end )
local handleClickX, handleClickY
local levermovement = 0

local clicksound = sound "../sound/click2.ogg"

sound { "../sound/motor.ogg", az = 84, el = -10, volume = 0.2, loop = true, autoplay = true }

local function redraw()
	pipmak.getpatch(1):setimage("lever"..math.floor(state.bridgepos*9 + 0.5).."-19.jpeg")
	pipmak.getpatch(2):setimage("lever"..math.floor(state.bridgepos*9 + 0.5).."-20.jpeg")
	pipmak.getpatch(3):setimage("lever"..math.floor(state.bridgepos*9 + 0.5).."-24.jpeg")
	pipmak.getpatch(4):setimage("bridge"..math.floor(state.bridgepos*9 + 0.5).."-19.png")
	pipmak.getpatch(5):setimage("bridge"..math.floor(state.bridgepos*9 + 0.5).."-23.jpeg")
end

local function movelever()
	clicksound:play()
	state.bridgepos = state.bridgepos + levermovement
	local r = nil
	if state.bridgepos <= 0.01 then
		state.bridgepos = 0
		levermovement = 0
	elseif state.bridgepos >= 0.99 then
		state.bridgepos = 1
		levermovement = 0
	else
		r = 0.2
	end
	redraw()
	return r
end

handle {
	az = ({[true] = 28.3, [false] = 63.6})[(state.bridgepos > 0.5)],
	el = ({[true] = -8.7, [false] = -18.8})[(state.bridgepos > 0.5)],
	w = 8, h = 14,
	cursor = pipmak.hand_open,
	onmousedown = function(self)
		handleClickX, handleClickY = self:location()
		pipmak.setcursor(pipmak.hand_closed)
	end,
	onmousestilldown = function(self)
		local nx = handleClickX + pipmak.mouseloc() - pipmak.clickloc()
		if nx < 28.3 then nx = 28.3
		elseif nx > 63.6 then nx = 63.6 end
		local ny = -0.008187*nx*nx + 0.4530*nx -14.71
		self:moveto(nx, ny)
		local oldbridgepos = state.bridgepos
		state.bridgepos = math.floor((4.239e-4*nx*nx - 0.06629*nx + 2.516)*9 + 0.5) / 9
		if (state.bridgepos ~= oldbridgepos) then
			clicksound:play()
			redraw()
		end
	end,
	onenddrag = function(self)
		pipmak.setcursor(pipmak.hand_open)
		if state.bridgepos > 0.5 then
			self:moveto(28.3, -8.7)
			levermovement = 1/9
			pipmak.schedule(0, movelever)
		else
			self:moveto(63.6, -18.8)
			levermovement = -1/9
			pipmak.schedule(0, movelever)
		end
		redraw()
	end
}

patch { face = 1, x = 398, y = 309, image = "lever"..math.floor(state.bridgepos*9 + 0.5).."-19.jpeg" }
patch { face = 2, x = 0, y = 320, image = "lever"..math.floor(state.bridgepos*9 + 0.5).."-20.jpeg" }
patch { face = 6, x = 240, y = 0, image = "lever"..math.floor(state.bridgepos*9 + 0.5).."-24.jpeg" }

patch { face = 1, x = 0, y = 0, image = "bridge"..math.floor(state.bridgepos*9 + 0.5).."-19.png" }
patch { face = 5, x = 0, y = 357, image = "bridge"..math.floor(state.bridgepos*9 + 0.5).."-23.jpeg" }

patch { face = 1, x = 229, y = 223, visible = state.lamp2on, image = "lamp2.jpeg" }
patch { face = 3, x = 256, y = 160, visible = state.lamp4on, image = "lamp4.jpeg" }
patch { face = 4, x = 351, y = 210, visible = state.lamp1on, image = "lamp1.jpeg" }

patch { face = 1, x = 148, y = 239, visible = state.doorisopen, image = "door.jpeg" }

local wheel = patch { face = 2, x = 199, y = 282, image = "wheel0.jpeg" }
local wheelpos = 0

onenternode (
	function()
		pipmak.schedule(
			0.05,
			function()
				wheelpos = math.mod(wheelpos + 1, 6)
				wheel:setimage("wheel" .. wheelpos .. ".jpeg")
				return 0.05
			end
		)
	end
)