slide "e.jpeg"

local button = patch { x = 555, y = 385, visible = false, image = "button.jpeg" }

local key = patch { x = 575, y = 208, visible = state.keyinhouse, image = "key.jpeg" }

patch { x = 370, y = 169, visible = state.lamp3on, image = "lamp.jpeg" }

local door = patch { x = 0, y = 16, visible = not state.doorisopen, image = "door.png" }


local click1 = sound { "../sound/click1.ogg", volume = 0.5 }
local click2 = sound { "../sound/click2.ogg", volume = 0.5 }
local doorslide = sound "../sound/slide.ogg"


hotspotmap "hotspots.png"

hotspot { target = 15, effect = { pipmak.rotate, pipmak.right, 90 }, cursor = pipmak.hand_lleft }

hotspot { target = 15, effect = { pipmak.rotate, pipmak.left, 90 }, cursor = pipmak.hand_rright }

hotspot {
	onmousedown = function()
		click1:play()
		button:setvisible(true)
		pipmak.schedule (
			0.4,
			function()
				click2:play()
				button:setvisible(false)
				pipmak.schedule(0.25, function() doorslide:play() end)
				state.doorisopen = not state.doorisopen
				pipmak.gethotspot(5):enable(state.doorisopen)
				pipmak.wipe(state.doorisopen and pipmak.left or pipmak.right, 1)
				door:setvisible(not state.doorisopen)
			end
		)
	end
}

hotspot {
	onmousedown = function()
		if state.keyinhouse then
			state.keyinhouse = false
			key:setvisible(false)
			inventory:message("pickup", "key")
		elseif state.inventory[state.inventory.carried] == "key" then
			state.keyinhouse = true
			key:setvisible(true)
			inventory:message("drop", state.inventory.carried)
		end
	end
}

hotspot {
	cursor = pipmak.hand_forward,
	enabled = state.doorisopen,
	onmousedown = function()
		backgroundsound:stop()
		backgroundsound = nil
		pipmak.gotonode(12)
	end
}
