cubic { "07.jpeg", "08.jpeg", "09.jpeg", "10.jpeg", "11.jpeg", "12.jpeg" }

hotspotmap "hotspots.png"

hotspot { target = 1, effect = { pipmak.dissolve, 2 }, cursor = pipmak.hand_forward }

hotspot { target = 3, effect = { pipmak.dissolve, 2 }, cursor = pipmak.hand_forward }

patch { face = 1, x = 283, y = 216, visible = state.lamp2on, image = "lamp2.jpeg" }
patch { face = 2, x = 188, y = 215, visible = state.lamp3on, image = "lamp3.jpeg" }
patch { face = 3, x = 157, y = 190, visible = state.lamp4on, image = "lamp4.jpeg" }
patch { face = 4, x = 307, y = 193, visible = state.lamp1on, image = "lamp1.jpeg" }

patch { face = 2, x = 263, y = 88, visible = (state.bridgepos > .5), image = "bridge.jpeg" }
