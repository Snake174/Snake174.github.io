slide "e.jpeg"

hotspotmap "hotspots.png"

hotspot { target = 11, effect = { pipmak.rotate, pipmak.right, 60 }, cursor = pipmak.hand_left }
hotspot { target = 13, effect = { pipmak.rotate, pipmak.left, 60 }, cursor = pipmak.hand_right }
hotspot { target = 19, cursor = pipmak.hand_forward }

patch { x = 379, y = 157, visible = state.lamp3on, image = "lamp.jpeg" }