slide "screen.png"

local r, g, b = 0, 0, 0
local l, delayedl = 0, 0
local animationrunning = false
local light, redknob, greenknob, blueknob

local tone = sound { "../sound/tone.ogg", loop = true }

light = patch { x = 132, y = 16, image = "light.png" }
light:setcolor(r, g, b)

redknob = patch { x = 211, y = 392, image = "redknob.png" }
greenknob = patch { x = 312, y = 392, image = "greenknob.png" }
blueknob = patch { x = 412, y = 392, image = "blueknob.png" }

local display = pipmak.newimage(37, 21)
display:color(.42, .42, .25):drawtext(3, 1, "000", "../resources/Vera.ttf", 16)
patch { x = 541, y = 358, anglex = -33, angley = 3, angle = -20, image = display }
local needle = patch { anchorh = 3.5, anchorv = 37, x = 564, y = 346, anglex = -33, angley = 3, angle = 121.5, image = "needle.png" }

-- run on a timer to make the gauge lag a bit behind the input
local function animatedisplay(now, last)
	local dt = (last ~= nil) and now - last or 0
	local d = math.exp(-7*dt)*(delayedl - l)
	delayedl = l + d
	needle:move { angle = 121.5 - 280*delayedl }
	display:color(0, 0, 0, 0):fill()
	display:color(.42, .42, .25):drawtext(3, 1, string.format("%03.0f", 100*delayedl), "../resources/Vera.ttf", 16)
	if (d < 0.002 and d > -0.002) then
		-- we have converged close enough, stop the animation
		animationrunning = false
		return
	else
		-- run again
		return 0
	end
end

local function update(p)
	if p == nil then p = 1 end
	light:setcolor(p*r, p*g, p*b)
	l = p*(0.30*r + 0.59*g + 0.11*b)
	if not animationrunning then
		animationrunning = true
		pipmak.schedule(0, animatedisplay)
	end
end

hotspotmap "hotspots.png"

hotspot {
	onmousedown = function()
		local t = pipmak.now();
		local knobsdone = false
		pipmak.schedule(
			0,
			function(now)
				local p = 1 - (now - t)/0.5
				if p < 0 then p = 0 end
				if not knobsdone then -- turn down the knobs
					redknob:moveto(219 + math.sin(p*r*3/2*math.pi)*21 - 8, 422 - math.cos(p*r*3/2*math.pi)*21 - 8)
					greenknob:moveto(320 + math.sin(p*g*3/2*math.pi)*21 - 8, 422 - math.cos(p*g*3/2*math.pi)*21 - 8)
					blueknob:moveto(420 + math.sin(p*b*3/2*math.pi)*21 - 8, 422 - math.cos(p*b*3/2*math.pi)*21 - 8)
					update(p)
					knobsdone = (p == 0)
					return 0
				elseif delayedl >= 0.005 then -- done with the knobs, wait for the gauge to reach 0
					return 0.2
				else -- done, switch nodes
					pipmak.gotonode(15)
				end
			end
		)
	end,
	cursor = pipmak.hand_back
}

hotspot {
	cursor = pipmak.hand_open,
	onmousedown = function()
		tone:play()
		pipmak.setcursor(pipmak.hand_closed)
	end,
	onenddrag = function()
		tone:stop()
		pipmak.setcursor(pipmak.hand_open)
	end,
	onmousestilldown = function()
		local x0, y0 = 219, 422
		local x, y = pipmak.mouseloc()
		x = x - x0
		y = y - y0
		if x == 0 and y == 0 then y = -1 end
		if x < 0 and y < 0 then
			if x <= y then y = 0
			else x = 0 end
		end
		x, y = x/math.sqrt(x^2+y^2), y/math.sqrt(x^2+y^2)
		r = 1/3 + math.atan2(y, x)/(3/2*math.pi)
		tone:pitch(1 + 0.5*r)
		redknob:moveto(x0 + x*21 - 8, y0 + y*21 - 8)
		update()
	end
}

hotspot {
	cursor = pipmak.hand_open,
	onmousedown = function()
		tone:play()
		pipmak.setcursor(pipmak.hand_closed)
	end,
	onenddrag = function()
		tone:stop()
		pipmak.setcursor(pipmak.hand_open)
	end,
	onmousestilldown = function()
		local x0, y0 = 320, 422
		local x, y = pipmak.mouseloc()
		x = x - x0
		y = y - y0
		if x == 0 and y == 0 then y = -1 end
		if x < 0 and y < 0 then
			if x <= y then y = 0
			else x = 0 end
		end
		x, y = x/math.sqrt(x^2+y^2), y/math.sqrt(x^2+y^2)
		g = 1/3 + math.atan2(y, x)/(3/2*math.pi)
		tone:pitch(1 + 0.5*g)
		greenknob:moveto(x0 + x*21 - 8, y0 + y*21 - 8)
		update()
	end
}

hotspot {
	cursor = pipmak.hand_open,
	onmousedown = function()
		tone:play()
		pipmak.setcursor(pipmak.hand_closed)
	end,
	onenddrag = function()
		tone:stop()
		pipmak.setcursor(pipmak.hand_open)
	end,
	onmousestilldown = function()
		local x0, y0 = 420, 422
		local x, y = pipmak.mouseloc()
		x = x - x0
		y = y - y0
		if x == 0 and y == 0 then y = -1 end
		if x < 0 and y < 0 then
			if x <= y then y = 0
			else x = 0 end
		end
		x, y = x/math.sqrt(x^2+y^2), y/math.sqrt(x^2+y^2)
		b = 1/3 + math.atan2(y, x)/(3/2*math.pi)
		tone:pitch(1 + 0.5*b)
		blueknob:moveto(x0 + x*21 - 8, y0 + y*21 - 8)
		update()
	end
}