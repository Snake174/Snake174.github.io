slide "telescope.jpeg"

hotspotmap "hotspots.png"

hotspot { target = 21, cursor = pipmak.hand_zoom }
hotspot { target = 20, effect = { pipmak.rotate, pipmak.left, 60 }, cursor = pipmak.hand_right }
