slide "back.jpeg"

hotspotmap "hotspots.png"

hotspot { target = 19, effect = { pipmak.rotate, pipmak.right, 60 }, cursor = pipmak.hand_left }
hotspot { target = 10, cursor = pipmak.hand_forward }
hotspot {
	onmousedown = function()
		pipmak.setviewdirection(210, 0)
		pipmak.gotonode(1)
	end,
	cursor = pipmak.hand_forward
}

patch { image = "door.jpeg", x = 416, y = 168, visible = state.doorisopen }