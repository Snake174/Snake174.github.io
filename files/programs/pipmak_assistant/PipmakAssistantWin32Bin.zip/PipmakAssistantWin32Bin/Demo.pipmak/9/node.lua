cubic { "49.jpeg", "50.jpeg", "51.jpeg", "52.jpeg", "53.jpeg", "54.jpeg" }

hotspotmap "hotspots.png"

hotspot { target = 8, cursor = pipmak.hand_forward }

local s1, s2, s3, s4, l1, l2, l3, l4, key

hotspot {
	dont_pan = true,
	onmousedown = function()
		if key:isvisible() then
			state.lamp1on = not state.lamp1on
			pipmak.dissolve(1, 0.2)
			l1:setvisible(state.lamp1on)
		end
	end,
	onhilite = function(self, h)
		s1:setvisible(h)
	end
}
hotspot {
	dont_pan = true,
	onmousedown = function()
		if key:isvisible() then
			state.lamp2on = not state.lamp2on
			l2:setvisible(state.lamp2on)
		end
	end,
	onhilite = function(self, h)
		s2:setvisible(h)
	end
}
hotspot {
	dont_pan = true,
	onmousedown = function()
		if key:isvisible() then
			state.lamp3on = not state.lamp3on
			l3:setvisible(state.lamp3on)
		end
	end,
	onhilite = function(self, h)
		s3:setvisible(h)
	end
}
hotspot {
	dont_pan = true,
	onmousedown = function()
		if key:isvisible() then
			state.lamp4on = not state.lamp4on
			l4:setvisible(state.lamp4on)
		end
	end,
	onhilite = function(self, h)
		s4:setvisible(h)
	end
}

hotspot {
	onmousedown = function()
		if key:isvisible() then
			local k = 4
			pipmak.schedule(
				0,
				function()
					k = k - 1
					if k > 0 then
						key:setimage("key"..k..".png")
						return 0.05
					else
						key:setvisible(false)
						inventory:message("pickup", "key")
					end
				end
			)
		elseif state.inventory[state.inventory.carried] == "key" then
			local k = 1
			inventory:message("drop")
			key:setimage("key1.png")
			key:setvisible(true)
			pipmak.schedule(
				0.05,
				function()
					k = k + 1
					key:setimage("key"..k..".png")
					if k < 4 then return 0.05 end
				end
			)
		end
	end
}

onleavenode ( function() if key:isvisible() then inventory:message("pickup", "key") end end )

patch { face = 1, x = 154, y = 316, visible = state.doorisopen, image = "door.jpeg" }

l2 = patch { face = 1, x = 241, y = 253, visible = state.lamp2on, image = "lamp2.jpeg" }
l3 = patch { face = 2, x = 143, y = 254, visible = state.lamp3on, image = "lamp3.jpeg" }
l4 = patch { face = 3, x = 226, y = 252, visible = state.lamp4on, image = "lamp4.jpeg" }
l1 = patch { face = 4, x = 327, y = 253, visible = state.lamp1on, image = "lamp1.jpeg" }

s1 = patch { face = 4, x = 232, y = 379, visible = false, image = "switch1.jpeg" }
s2 = patch { face = 4, x = 265, y = 395, visible = false, image = "switch2.jpeg" }
s3 = patch { face = 4, x = 225, y = 416, visible = false, image = "switch3.jpeg" }
s4 = patch { face = 4, x = 193, y = 395, visible = false, image = "switch4.jpeg" }

key = patch { face = 6, x = 0, y = 207, visible = false, image = "key1.png" }
