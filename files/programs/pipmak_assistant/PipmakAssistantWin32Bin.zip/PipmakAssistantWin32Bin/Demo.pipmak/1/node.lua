cubic { "01.jpeg", "02.jpeg", "03.jpeg", "04.jpeg", "05.jpeg", "06.jpeg" }

onenternode (
	function()
		if not state.welcomed then
			pipmak.schedule (
				1.5,
				function()
					pipmak.print("There you go!\
This, by the way, is the Pipmak terminal, which is used for error messages and the like.")
				end
			)
			pipmak.schedule(5, function() pipmak.print("But I'll be out of your way now...") end)
			state.welcomed = true
		end
	end
)

hotspotmap "hotspots.png"

hotspot { target = 10, cursor = pipmak.hand_forward }
hotspot { target = 2, effect = { pipmak.dissolve, 2 }, cursor = pipmak.hand_forward }
hotspot { target = 19, cursor = pipmak.hand_forward }

patch { face = 1, x = 72, y = 198, visible = state.doorisopen, image = "door.jpeg" }

patch { face = 1, x = 255, y = 206, visible = state.lamp2on, image = "lamp2.jpeg" }
patch { face = 2, x = 237, y = 211, visible = state.lamp3on, image = "lamp3.jpeg" }
patch { face = 4, x = 234, y = 202, visible = state.lamp1on, image = "lamp1.jpeg" }

patch { face = 3, x = 104, y = 88, visible = (state.bridgepos > .5), image = "bridge.jpeg" }
