version (0.27)

title "Pipmak Demo"
startnode (99)

onopenproject (
	function()
		state.doorisopen = false
		state.lamp1on = false
		state.lamp2on = false
		state.lamp3on = false
		state.lamp4on = false
		state.bridgepos = 0
		state.keyinhouse = true
		state.inventory = {"note"}
	end
)
