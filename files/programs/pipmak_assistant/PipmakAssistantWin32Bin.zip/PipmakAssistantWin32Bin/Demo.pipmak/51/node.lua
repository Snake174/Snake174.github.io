slide { "note.png", border = false, mousemode = pipmak.joystick }

--a full-slide hotspot will also trigger when clicking outside of the slide (in the aspect-ratio-correction borders), whereas a full-slide handle won't
hotspotmap "hotspot1.png" 
hotspot { onmousedown = function() pipmak.thisnode():closeoverlay() end, cursor = pipmak.hand_back }
