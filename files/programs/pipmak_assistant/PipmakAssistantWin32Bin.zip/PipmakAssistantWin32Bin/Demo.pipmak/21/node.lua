cubic { "dummy.png", "dummy.png", "57.jpeg", "dummy.png", "dummy.png", "dummy.png", cursor = pipmak.pan, mousemode = pipmak.joystick }

limits { minaz = 143, maxaz = 217, minel = -15, maxel = 20 }

patch { face = 3, x = 528, y = 432, visible = state.lamp4on, image = "lamp4.jpeg" }
patch { face = 3, x = 520, y = 320, visible = (state.bridgepos > .5), image = "bridge.png" }

local frame

onenternode(
	function()
		frame = pipmak.overlaynode(22)
		if not state.node21inited then --don't redo this setup when we're loading a saved game
			pipmak.setverticalfov(pipmak.getverticalfov()/3)
			pipmak.setjoystickspeed(pipmak.getjoystickspeed()/3)
			pipmak.setviewdirection(180, 5)
			state.node21inited = true
		end
	end
)
onleavenode(
	function()
		frame:closeoverlay()
		pipmak.setverticalfov(pipmak.getverticalfov()*3)
		pipmak.setjoystickspeed(pipmak.getjoystickspeed()*3)
		state.node21inited = nil
	end
)

--we don't want the inventory to get in our way
onenternode(function() if inventory and inventory.closeoverlay then inventory:closeoverlay() end end) --the test is necessary since when we're loading a saved game, the inventory is already closed, i.e. the global variable 'inventory' is either nil or references the remains of an old, invalid node (that doesn't have a closeoverlay method anymore)
onleavenode(function() inventory = pipmak.overlaynode(50) end)
