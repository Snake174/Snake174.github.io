cubic { "43.jpeg", "44.jpeg", "45.jpeg", "46.jpeg", "47.jpeg", "48.jpeg" }

hotspotmap "hotspots.png"

hotspot { target = 7, cursor = pipmak.hand_forward }
hotspot { target = 9, cursor = pipmak.hand_forward, enabled = (state.bridgepos > .5) }

patch { face = 1, x = 35, y = 316, visible = state.doorisopen, image = "door.jpeg" }

patch { face = 4, x = 312, y = 253, visible = state.lamp1on, image = "lamp1.jpeg" }
patch { face = 1, x = 192, y = 253, visible = state.lamp2on, image = "lamp2.jpeg" }
patch { face = 2, x = 102, y = 253, visible = state.lamp3on, image = "lamp3.jpeg" }
patch { face = 3, x = 329, y = 253, visible = state.lamp4on, image = "lamp4.jpeg" }

patch { face = 4, x = 183, y = 217, visible = (state.bridgepos <= .5), image = "bridgeup.png" }

patch { face = 6, x = 56, y = 382, visible = (state.bridgepos > .5), image = "lever.jpeg" }

sound { "../sound/motor.ogg", az = 132, el = -55, volume = 0.1, loop = true, autoplay = true }
