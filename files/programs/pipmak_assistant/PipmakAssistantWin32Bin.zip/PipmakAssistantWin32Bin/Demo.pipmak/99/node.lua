slide "welcome.png"

hotspotmap "hotspotmap.png"

patch {
	x = 197, y = 269,
	visible = false,
	image = "hilite.png"
}

hotspot {
	onmouseup = function(self)
		pipmak.overlaynode(50) --inventory
		pipmak.rotate(pipmak.left, -60, 1)
		pipmak.gotonode(1)
	end,
	onhilite = function(self, h)
		pipmak.getpatch(1):setvisible(h)
	end
}

patch { x = 337, y = 136, image = pipmak.newimage(29, 14):fill():color(1, 1, 1):drawtext(1, 0, "0.2.7") }

patch { x = 337, y = 457, image = pipmak.newimage(60, 12):fill():color(1, 1, 1):drawtext(4, 0, "2004–2008", "../resources/Vera.ttf", 9) }
